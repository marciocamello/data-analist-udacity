# Udacity Data Analyst Nanodegree Projects

This is my project submissions for [Udacity Data Analyst Nanodegree](https://www.udacity.com/course/data-analyst-nanodegree--nd002) program.

## Project 0: [Great size of Hashi](https://github.com/marciocamello/udacity/projects/projects/great-size-of-hashi)

## Project 1: [Testing a phenomenon of perception](https://github.com/marciocamello/udacity/projects/pesting-a-phenomenon-of-perception)

## Project 2: [Investigating a Database](https://github.com/marciocamello/udacity/projects/investigating-a-database)

## Project 3: [Cleaning OpenStreetMap data](https://github.com/marciocamello/udacity/projects/cleaning-openstreetmap-data)

## Project 4: [Explore and summarize data](https://github.com/marciocamello/udacity/projects/explore-and-summarize-data)

## Project 5: [Identify fraud and Mail Enron](https://github.com/marciocamello/udacity/projects/identify-fraud-and-mail-enron)

## Project 6: [Make Data Visualization Effective](https://github.com/marciocamello/udacity/projects/make-data-visualization-effective)

## Project 7: [Test A/B Project](https://github.com/marciocamello/udacity/projects/test-ab-project)
